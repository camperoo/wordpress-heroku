<form role="search" method="get" class="searchform" action="<?php echo home_url( '/' ); ?>">
	<input type="text" placeholder="<?php _e('Search...', 'rey'); ?>" name="s" class="s" />
</form>